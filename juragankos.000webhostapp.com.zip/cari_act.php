<?php 
$cari=$_GET['cari'];
header("location:index.php?menu=listkamar&action=tampil&cari=$cari");
?>