<?php
$isi_pesan = "
	<div>
		<h3>Admin JuraganKos<br></h3>
	</div>
	<br>Kami telah mengatur ulang password Anda, Berikut Data beserta password baru Anda :<br><br>
	<table>
		<tr>
			<td><b>Nama</b><td>: ".$member_nama."</td></td>
		</tr>
		<tr>
			<td><b>Email</b><td>: <b>".$member_email."</b></td></td>
		</tr>
		<tr>
			<td><b>Password Baru</b><td>: <b>".$passwordbaru."</b></td></td>
		</tr>
		<br>Setelah anda berhasil melakukan Login disarankan langsung ganti password<br><br>
	</table>
	<br><br>
	<center>
		<p>Developer Berbagi Ilmu<br></p>
	<center>
		<small>
			<p> Copyright &copy; ".date("Y")." JuraganKos All Right Reserved</p>
		</small>
	</center>";
?>
